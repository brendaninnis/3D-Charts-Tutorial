
import Foundation

enum Constants {
    static let verticalSpacing: CGFloat = 8
    static let horizontalMargin: CGFloat = 48
}
